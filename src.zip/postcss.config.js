// postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {}, // Ensure this is correct
    autoprefixer: {},
  },
};
